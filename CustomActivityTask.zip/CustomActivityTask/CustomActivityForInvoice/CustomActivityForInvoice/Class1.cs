﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Activities;
using System.ComponentModel;
using iTextSharp.text.pdf;
using iTextSharp.text.pdf.parser;
using PDFText;

namespace CustomActivityForInvoice
{
    public class Invoice:CodeActivity

    {
        [Category("Input")]
        [RequiredArgument]
        public InArgument<string> InputPDF { get; set; }
        [Category("Input")]
        [RequiredArgument]
        public InArgument<string> Keyword { get; set; }

        [Category("Output")]
        public OutArgument<string> InvoiceNumber { get; set; }
       
        [Category("Output")]
        public OutArgument<string> Coordinates { get; set; }

        protected override void Execute(CodeActivityContext context)
        {
           
                string filePath = InputPDF.Get(context);
                PdfReader pdfReader = new PdfReader(filePath);
                int NumberOfPages = pdfReader.NumberOfPages;
                var parser = new PdfReaderContentParser(pdfReader);
                var keyword2 = Keyword.Get(context);
                var strategy = parser.ProcessContent(1, new LocationTextExtractionStrategyWithPosition());
                var res = strategy.GetLocations();
                pdfReader.Close();
                var searchResult = res.Where(p => p.Text.Contains(keyword2)).OrderBy(p => p.Y).Reverse().ToList();
                var number= searchResult[0].Text.Split(':')[1].Split(' ')[1].Split(' ')[0];
                // var Number= searchResult[0].Text.Split(':')[1].ToString().Split(' ')[1].Split(' ')[0];
                var coordinates = searchResult[0].X + " ; " +searchResult[0].Y;


               InvoiceNumber.Set(context, number);
               Coordinates.Set(context, coordinates);


        }

    }
}
